FREE FIRE SAFE PANEL — Android Studio project

Yeh Android 10 (API 29) compatible floating companion panel ka project hai.
Yeh APK nahi, Android Studio project source hai.

Build karne ke liye:
1. ZIP ko PC par extract karein.
2. Android Studio mein 'Open' karke FreeFireSafePanel folder select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) chunein.
5. APK ko apne phone mein install karein.
6. App kholkar 'Enable Floating Panel' dabayein aur 'Display over other apps' permission allow karein.
7. Free Fire kholne par panel screen par dikhega. Header ko drag karke move kar sakte hain.

Important:
- Is app mein aimbot, ESP, no-recoil, game-file modification ya anti-ban bypass nahi hai.
- Panel sirf legitimate in-game settings ke shortcuts/tips dikhata hai.
- Android Studio aur compatible JDK ki zaroorat hai.
