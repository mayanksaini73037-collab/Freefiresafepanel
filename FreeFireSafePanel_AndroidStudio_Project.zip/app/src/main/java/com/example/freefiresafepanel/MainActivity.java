package com.example.freefiresafepanel;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    int purple = Color.rgb(139, 53, 255);
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 30, 24, 24);
        root.setBackgroundColor(Color.rgb(12, 8, 22));
        TextView title = new TextView(this);
        title.setText("FREE FIRE  •  SAFE PANEL");
        title.setTextColor(Color.WHITE); title.setTextSize(24); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));
        TextView desc = new TextView(this);
        desc.setText("Floating companion for Android 10\nSensitivity • HUD • DPI notes • Graphics guide");
        desc.setTextColor(Color.LTGRAY); desc.setTextSize(15); desc.setGravity(Gravity.CENTER);
        root.addView(desc, new LinearLayout.LayoutParams(-1, 80));
        Button start = button("ENABLE FLOATING PANEL");
        root.addView(start, new LinearLayout.LayoutParams(-1, 58));
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, FloatingPanelService.class));
                finish();
            }
        });
        TextView note = new TextView(this);
        note.setText("\nNote: This app only displays legitimate setup tips. It does not modify Free Fire, inject files, or provide cheats such as aimbot/ESP/no-recoil.");
        note.setTextColor(Color.GRAY); note.setTextSize(13);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
    Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        return b;
    }
}
