package com.example.freefiresafepanel;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingPanelService extends Service {
    WindowManager wm; View panel; WindowManager.LayoutParams params;
    int purple = Color.rgb(139, 53, 255);
    public IBinder onBind(Intent i) { return null; }

    public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 10, 14, 12);
        box.setBackgroundColor(Color.rgb(18, 12, 31));

        TextView header = new TextView(this);
        header.setText("✦ FF SAFE PANEL     [MOVE]");
        header.setTextColor(Color.WHITE); header.setTextSize(16);
        header.setTypeface(null, Typeface.BOLD); header.setPadding(4, 8, 4, 12);
        box.addView(header);

        addInfo(box, "SENSITIVITY", "Open Free Fire → Settings → Sensitivity");
        addInfo(box, "CUSTOM HUD", "Settings → Controls → Custom HUD");
        addInfo(box, "DPI", "Use your phone's normal display settings; no forced DPI change.");
        addInfo(box, "GRAPHICS", "Choose Smooth graphics and the highest stable FPS option available.");
        addInfo(box, "BATTERY", "Close background apps and avoid playing while the phone is overheating.");

        Button close = new Button(this); close.setText("CLOSE PANEL");
        close.setTextColor(Color.WHITE);
        close.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        box.addView(close, new LinearLayout.LayoutParams(-1, 48));
        close.setOnClickListener(v -> stopSelf());

        header.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx=params.x; sy=params.y; tx=e.getRawX(); ty=e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x=sx+(int)(e.getRawX()-tx); params.y=sy+(int)(e.getRawY()-ty);
                    wm.updateViewLayout(panel, params); return true;
                }
                return true;
            }
        });

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 20; params.y = 120;
        panel = box;
        wm.addView(panel, params);
    }

    void addInfo(LinearLayout parent, String heading, String detail) {
        TextView t = new TextView(this);
        t.setText(heading + "\n" + detail);
        t.setTextColor(Color.WHITE); t.setTextSize(13);
        t.setPadding(8, 8, 8, 10);
        parent.addView(t);
    }
    public void onDestroy() {
        if (wm != null && panel != null) wm.removeView(panel);
        super.onDestroy();
    }
}
